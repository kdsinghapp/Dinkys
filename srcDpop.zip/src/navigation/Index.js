import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { TransitionPresets, createStackNavigator } from '@react-navigation/stack';
import Splash from '../screens/auth/Splash';
import Login from '../screens/auth/Login';
import Bottomtab from '../screens/BottomTab';
import ChooseLanguage from '../screens/auth/ChooseLanguage';
import Privacy from '../screens/profile/Privacy';
import TermAndCondition from '../screens/profile/TermAndCondition';
import About from '../screens/profile/About';
import EditProfile from '../screens/profile/EditProfile';
import Notification from '../screens/profile/Notification';
import ResetPassByNumber from '../screens/auth/ResetPassByNumber';
import Otp from '../screens/auth/Otp';
import NewPassword from '../screens/auth/NewPassword';
import AllCategories from '../screens/Home/AllCategories';
import Favrotie from '../screens/Home/Favrotie';
import SettingScreen from "../screens/profile/SettingScreen"
import ChangePassword from '../screens/profile/ChangePassword';
import ShippingAddress from '../screens/profile/ShippingAddress';
import FAQ from '../screens/profile/FAQ';
import BallanceHistory from '../screens/profile/BallanceHistory';
import Wallet from '../screens/profile/Wallet';
import BankScreen from '../screens/profile/BankScreen';
import Sales from '../screens/profile/Sales';
import Purchases from '../screens/profile/Purchases';
import ProductDetails from '../screens/Home/ProductDetails';
import Delivery from '../screens/Home/Delivery';
import Map from '../screens/Home/Map';
import Summary from '../screens/Home/Summary';
import ChattingScreen from '../screens/Home/ChattingScreen';
import Register from '../screens/auth/Register';
import ProductList from '../screens/Home/ProductList';
import AddProduct from '../screens/Home/AddProduct';
import WebViewScreen from '../screens/Home/WebView';
import WalletAmount from '../screens/profile/WalletAmount';
import AddAddress from '../screens/profile/AddAddress';
import AddCardDetails from '../screens/profile/AddCardDetails';
import { notificationListener, requestUserPermission } from '../utils/Notification';
const Stack = createStackNavigator();
export default function Navigation() {

    React.useEffect(() => {
        notificationListener();
        requestUserPermission();
      }, []);

    const screenOptions = {
        headerShown: false,
        cardStyle: { backgroundColor: '#f7f7f7' },
        ...TransitionPresets.SlideFromRightIOS
    }
    const verticalAnimation = {
        headerShown: false,
        cardStyle: { backgroundColor: '#f7f7f7' },
        cardOverlayEnabled: true,
        ...TransitionPresets.ModalSlideFromBottomIOS
    }
    const verticalAnimationTransparent = {
        headerShown: false,
        cardStyle: { backgroundColor: 'transparent' },
        cardOverlayEnabled: true,
        ...TransitionPresets.SlideFromRightIOS
    }
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName={"Splash"} screenOptions={screenOptions} >
                <Stack.Screen name="Splash" component={Splash} options={verticalAnimationTransparent} />
                <Stack.Screen name="Register" component={Register} options={verticalAnimationTransparent} />
                <Stack.Screen name="Login" component={Login} options={verticalAnimationTransparent} />
                <Stack.Screen name="Otp" component={Otp} options={verticalAnimationTransparent} />
                <Stack.Screen name="ResetPassByNumber" component={ResetPassByNumber} options={verticalAnimationTransparent} />
                <Stack.Screen name="ChooseLanguage" component={ChooseLanguage} options={verticalAnimationTransparent} />
                <Stack.Screen name="NewPassword" component={NewPassword} options={verticalAnimationTransparent} />
                <Stack.Screen name="Bottomtab" component={Bottomtab} options={verticalAnimationTransparent} />
                <Stack.Screen name="AllCategories" component={AllCategories} options={verticalAnimationTransparent} />
                <Stack.Screen name="Favrotie" component={Favrotie} options={verticalAnimationTransparent} />
                <Stack.Screen name="SettingScreen" component={SettingScreen} options={verticalAnimationTransparent} />
                <Stack.Screen name="ChangePassword" component={ChangePassword} options={verticalAnimationTransparent} />
                <Stack.Screen name="ShippingAddress" component={ShippingAddress} options={verticalAnimationTransparent} />
                <Stack.Screen name="Notification" component={Notification} options={verticalAnimationTransparent} />
                <Stack.Screen name="FAQ" component={FAQ} options={verticalAnimationTransparent} />
                <Stack.Screen name="BallanceHistory" component={BallanceHistory} options={verticalAnimationTransparent} />
                <Stack.Screen name="Wallet" component={Wallet} options={verticalAnimationTransparent} />
                <Stack.Screen name="BankScreen" component={BankScreen} options={verticalAnimationTransparent} />
                <Stack.Screen name="Sales" component={Sales} options={verticalAnimationTransparent} />
                <Stack.Screen name="Purchases" component={Purchases} options={verticalAnimationTransparent} />
                <Stack.Screen name="ProductDetails" component={ProductDetails} options={verticalAnimationTransparent} />
                <Stack.Screen name="Delivery" component={Delivery} options={verticalAnimationTransparent} />
                <Stack.Screen name="Map" component={Map} options={verticalAnimationTransparent} />
                <Stack.Screen name="Summary" component={Summary} options={verticalAnimationTransparent} />
                <Stack.Screen name="ChattingScreen" component={ChattingScreen} options={verticalAnimationTransparent} />
                <Stack.Screen name="Privacy" component={Privacy} options={verticalAnimationTransparent} />
                <Stack.Screen name="TermAndCondition" component={TermAndCondition} options={verticalAnimationTransparent} />
                <Stack.Screen name="About" component={About} options={verticalAnimationTransparent} />
                <Stack.Screen name="EditProfile" component={EditProfile} options={verticalAnimationTransparent} />
                <Stack.Screen name="ProductList" component={ProductList} options={verticalAnimationTransparent} />
                <Stack.Screen name="AddProduct" component={AddProduct} options={verticalAnimationTransparent} />
                <Stack.Screen name="WebViewScreen" component={WebViewScreen} options={verticalAnimationTransparent} />
                <Stack.Screen name="WalletAmount" component={WalletAmount} options={verticalAnimationTransparent} />
                <Stack.Screen name="AddAddress" component={AddAddress} options={verticalAnimationTransparent} />
                <Stack.Screen name="AddCardDetails" component={AddCardDetails} options={verticalAnimationTransparent} />
           
            </Stack.Navigator>
        </NavigationContainer>
    );
}

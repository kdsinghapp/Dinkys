
/* eslint-disable semi */
/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from 'react'
import { Image, Pressable, ScrollView, Alert, View, FlatList, TouchableOpacity, TextInput, BackHandler, ActivityIndicator } from 'react-native'
import MyText from '../../elements/MyText'
import { useSelector } from 'react-redux'
import MyStatusBar from '../../elements/MyStatusBar'
import BackNav from "../../assets/svg/BackNav.svg"
import PinSvg from "../../assets/svg/pin.svg"
import ShareSvg from "../../assets/svg/share.svg"
import HeartSvg from "../../assets/svg/heart.svg"
import HeartColorSvg from "../../assets/svg/heartColor.svg"
import ChatIcon from "../../assets/svg/chaticon.svg"
import ShieldSvg from "../../assets/svg/shiled.svg"
import MyButton from '../../elements/MyButton'
import { useFocusEffect } from '@react-navigation/native'
import { DOMAIN } from '../../services/Config'
import { AirbnbRating } from 'react-native-ratings';
import Theme from '../../theme'
import { errorToast } from '../../utils/customToast'


const ProductDetails = ({ navigation, route }) => {
    const userDetails = useSelector((state) => state?.user?.user)
    const { item } = route?.params
    const [details, setDetails] = useState(null)
    const [loading, setLoading] = useState(false)
    const [rating, setRating] = useState("3")
    const [message, setMessage] = useState()
    const [ratingData, setRatingData] = useState([])

    useFocusEffect(
        React.useCallback(() => {
            _getProductdetails()
            get_rating()
        }, [])
    )

    const ratingCompleted = (rating) => {
        setRating(rating)
    }

    const get_rating = () => {
        setLoading(true)
        var formdata = new FormData();
        formdata.append("product_id", !item?.product_data?.id ? item?.id : item?.product_data?.id);
        const requestOptions = {
            method: "POST",
            body: formdata,
            redirect: "follow"
        };
        fetch(`${DOMAIN}get-reviews`, requestOptions)
            .then((response) => response.json())
            .then((res) => {
                if (res?.status == "1") {
                    setRatingData(res?.result)
                }
            }).catch((err) => {
                console.log("err", err)
            }).finally(() => {
                setLoading(false)
            })
    }

    const _rating = () => {
        if (!message) {
            errorToast("Enter Something...")
        } else {
            setLoading(true)
            var formdata = new FormData();
            formdata.append("user_id", userDetails?.id);
            formdata.append("product_id", !item?.product_data?.id ? item?.id : item?.product_data?.id);
            formdata.append("rating", rating);
            formdata.append("message", message);
            const requestOptions = {
                method: "POST",
                body: formdata,
                redirect: "follow"
            };
            fetch(`${DOMAIN}add-review`, requestOptions)
                .then((response) => response.json())
                .then(async (res) => {
                    if (res.status == "1") {
                        get_rating()
                        setMessage("")
                    }
                }).catch((err) => {
                    console.log("err", err)
                })
        }
    }

    const _getProductdetails = () => {
        const myHeaders = new Headers();
        myHeaders.append("Accept", "application/json");
        myHeaders.append("Authorization", `Bearer ${userDetails?.access_token}`);
        var formdata = new FormData();
        formdata.append("product_id", !item?.product_data?.id ? item?.id : item?.product_data?.id);
        const requestOptions = {
            method: "POST",
            body: formdata,
            headers: myHeaders,
            redirect: "follow"
        };
        fetch(`${DOMAIN}get-product-details`, requestOptions)
            .then((response) => response.json())
            .then(async (res) => {
                if (res.status == "1") {
                    setDetails(res?.product_data)
                }
            }).catch((err) => {
                console.log("err", err)
            })
    }

    const add_fav = () => {
        setLoading(true)
        var formdata = new FormData();
        formdata.append("user_id", userDetails?.id);
        formdata.append("product_id", !item?.product_data?.id ? item?.id : item?.product_data?.id);
        const requestOptions = {
            method: "POST",
            body: formdata,
            redirect: "follow"
        };
        fetch(`${DOMAIN}add-favourite-product`, requestOptions)
            .then((response) => response.json())
            .then(async (res) => {
                if (res.status == "1") {
                    _getProductdetails()
                }
            }).catch((err) => {
                console.log("err", err)
            }).finally(() => {
                setLoading(false)
            })
    }

    const remove_fav = () => {
        setLoading(true)
        var formdata = new FormData();
        formdata.append("fav_id", !item?.product_data?.id ? item?.id : item?.product_data?.id);
        const requestOptions = {
            method: "POST",
            body: formdata,
            redirect: "follow"
        };
        fetch(`${DOMAIN}delete-favourite`, requestOptions)
            .then((response) => response.json())
            .then(async (res) => {
                if (res.status == "1") {
                    _getProductdetails()
                }
            }).catch((err) => {
                console.log("err", err)
            }).finally(() => {
                setLoading(false)
            })
    }

    return (
        <View style={{ flex: 1, backgroundColor: "#fff" }}>
            <ScrollView style={{ backgroundColor: "#fff", flex: 1 }}>
                <View style={{ backgroundColor: "#000", height: 350 }}>
                    <Image source={{ uri: item?.product_images?.[0]?.image }} style={{ width: "100%", height: "100%" }} />
                    <MyStatusBar backgroundColor={"transparent"} barStyle={"dark-content"} />
                    <View style={{ width: "90%", alignSelf: "center", flexDirection: "row", alignItems: "center", justifyContent: "space-between", position: "absolute", top: 60 }}>
                        <Pressable onPress={() => navigation.goBack()}>
                            <BackNav width={32} height={32} />
                        </Pressable>
                        <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 15 }}>
                            <ShareSvg width={28} height={28} />
                            <Pressable onPress={() => details?.favourite == false ? add_fav() : remove_fav()}>
                                {loading ? <ActivityIndicator size={"small"} />
                                    :
                                    !details?.favourite ?
                                        <HeartSvg width={24} height={24} />
                                        :
                                        <HeartColorSvg width={24} height={24} />
                                }
                            </Pressable>
                        </View>
                    </View>
                </View>
                <View style={{ padding: 20, flex: 1 }}>
                    <MyText h3 bold style={{ color: "#04CFA4" }}>
                        € {item?.price}
                    </MyText >
                    <MyText h4 semibold style={{ color: "#1C1B1B", marginTop: 5 }}>
                        {item?.brand}
                    </MyText >
                    <MyText h6 semibold style={{ color: "#949494" }}>
                        {item?.description}
                    </MyText >
                    <View style={{ width: "100%", borderRadius: 30, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginVertical: 18 }}>
                        <View style={{ width: 50, height: 50, borderRadius: 50 / 2, backgroundColor: "#04CFA433", overflow: "hidden" }} >
                            <Image source={{ uri: details?.user_data?.image }} style={{ width: "100%", height: "100%" }} />
                        </View>
                        <View style={{ width: "60%" }}>
                            <MyText h4 semibold style={{ color: "#1C1B1B" }}>
                                {details?.user_data?.user_name}
                            </MyText >
                            <MyText h6 regular style={{ color: "#1C1B1B" }}>
                                4.5 (2,495 reviews)
                            </MyText >
                        </View>
                        <Pressable onPress={() => details == null ? null : navigation.navigate("ChattingScreen", {
                            item: {
                                image: "",
                                name: details?.user_data?.user_name,
                                product_id: details?.id,
                                reciever_id: details?.user_id
                            }
                        })}>
                            <ChatIcon width={87} height={44} />
                        </Pressable>
                    </View>
                    <MyText h5 regular style={{ color: "#C3C6C9" }}>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa feugiat cum lorem nunc.........Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa feugiat cum lorem nunc.........Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa feugiat cum lorem nunc.........Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa feugiat cum lorem nunc.........Read more.
                    </MyText >
                    <View style={{ width: "100%", borderRadius: 12, flexDirection: "row", alignItems: "center", gap: 15, marginVertical: 18, padding: 15, backgroundColor: "#04CFA433" }}>
                        <View style={{ width: 26, height: 26, borderRadius: 26 / 2, backgroundColor: "#04CFA433" }} />
                        <View style={{ width: "80%" }}>
                            <MyText h6 regular style={{ color: "#04CFA4" }}>
                                You can save money and help the planet when you buy second-hand products
                            </MyText >
                            <MyText h6 regular style={{ color: "#04CFA4", marginTop: 15 }}>
                                More information
                            </MyText >
                        </View>
                    </View>
                    <MyText h2 bold style={{ color: "#393F48" }}>
                        Delivery in 3-7 days
                    </MyText >

                    <View style={{ width: "100%", flexDirection: "row", alignItems: "center", gap: 15, padding: 5, paddingVertical: 18, borderBottomWidth: 1, borderColor: "#EDEDED" }}>
                        <PinSvg width={44} height={44} />
                        <View style={{ width: "80%" }}>
                            <MyText h4 bold style={{ color: "#1C1B1B" }}>
                                At collection point from €2.99
                            </MyText >
                            <MyText h5 regular style={{ color: "#04CFA4" }}>
                                See nearby points
                            </MyText >
                        </View>
                    </View>
                    <View style={{ width: "100%", flexDirection: "row", alignItems: "center", gap: 12, padding: 5, paddingVertical: 18, borderBottomWidth: 1, borderColor: "#EDEDED" }}>
                        <PinSvg width={44} height={44} />
                        <View style={{ width: "80%" }}>
                            <MyText h4 bold style={{ color: "#1C1B1B" }}>
                                At my address from €3.49
                            </MyText >
                            <MyText h5 regular style={{ color: "#04CFA4" }}>
                                Send to 47011 Valladolid
                            </MyText >
                        </View>
                    </View>
                    <View style={{ width: "100%", borderRadius: 12, marginVertical: 18, padding: 15, borderWidth: 1, borderColor: "#EDEDED" }}>
                        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                            <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 15 }}>
                                <ShieldSvg width={28} height={28} />
                                <MyText h5 bold style={{ color: "#000000" }}>
                                    Dpop Protection
                                </MyText >
                            </View>
                            <Pressable onPress={() => navigation.goBack()}>
                                <MyText h5 bold style={{ color: "#04CFA4" }}>
                                    + Info
                                </MyText >
                            </Pressable>
                        </View>
                        <MyText h6 regular style={{ color: "#C3C6C9", marginTop: 15 }}>
                            Buy without worries through our shipping service. Transaction protected with refunds, secure payments and help whenever you need it.
                        </MyText >
                    </View>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 15 }}>
                        <PinSvg width={28} height={28} />
                        <MyText h5 bold style={{ color: "#000000" }}>
                            {details?.product_location}
                        </MyText >
                    </View>
                    <View style={{ borderWidth: 1, borderColor: "#EDEDED", height: 100, borderRadius: 12, marginVertical: 18 }}>
                    </View>
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                        <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 15 }}>
                            <MyText h4 bold style={{ color: "#000000" }}>
                                Review
                            </MyText >
                            <MyText h5 bold style={{ color: "#000000" }}>
                                5.0
                            </MyText >
                        </View>
                        <Pressable onPress={() => navigation.goBack()}>
                            <MyText h5 semibold style={{ color: "#04CFA4" }}>
                                See all
                            </MyText >
                        </Pressable>
                    </View>
                    <View style={{ marginTop: 20 }}>
                        <AirbnbRating
                            count={5}
                            defaultRating={3}
                            size={20}
                            showRating={false}
                            onFinishRating={ratingCompleted}
                        />
                        <TextInput multiline value={message} style={{ color: "#000", borderRadius: 12, padding: 15, paddingVertical: 20, paddingTop: 15, width: "100%", marginVertical: 20, backgroundColor: "#EBEEED", fontSize: 16 }} placeholder={"Add Comment"} placeholderTextColor={"#000"} onChangeText={(e) => setMessage(e)} />
                        <MyButton loading={loading} onPress={_rating} textStyle={{ fontSize: 16, fontFamily: Theme.FONT_FAMILY_SEMIBOLD }} style={{ borderRadius: 15, width: "100%", alignSelf: "center", marginBottom: 20 }} title={"Submit"} />
                        {ratingData?.length == 0 ? null
                            :
                            ratingData?.map((item, index) => {
                                return (
                                    <View key={index} style={{ width: "100%", borderRadius: 12, marginBottom: 18, padding: 15, borderWidth: 1, borderColor: "#EDEDED" }}>
                                        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                                            <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 15 }}>
                                                <View style={{ width: 36, height: 36, borderRadius: 36 / 2, backgroundColor: "#04CFA433", overflow: "hidden" }} >
                                                    <Image source={{ uri: item?.user_data?.[0]?.image }} style={{ width: "100%", height: "100%" }} />
                                                </View>
                                                <MyText h5 bold style={{ color: "#000000" }}>
                                                    {item?.user_data?.[0].user_name}
                                                </MyText >
                                            </View>
                                            <View style={{ borderRadius: 8, padding: 2, paddingHorizontal: 20, borderWidth: 1, borderColor: "#FFD33C" }} >
                                                <MyText h5 bold style={{ color: "#FFD33C" }}>
                                                    {item?.rating} *
                                                </MyText >
                                            </View>
                                        </View>
                                        <MyText h6 regular style={{ color: "#677294", marginTop: 15 }}>
                                            {item?.message}
                                        </MyText >
                                    </View>
                                )
                            })}
                    </View>
                    <MyText h5 bold style={{ color: "#04CFA4", alignSelf: "center" }}>
                        Report product
                    </MyText >
                    <MyButton onPress={() => navigation.navigate("Delivery", { details })} title={"Buy"} style={{ borderRadius: 12, marginVertical: 10 }} />
                </View>
            </ScrollView>

        </View>
    )
}

export default ProductDetails

/* eslint-disable semi */
/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from 'react'
import { Image, Pressable, ScrollView, Alert, View, FlatList, TouchableOpacity, TextInput, BackHandler } from 'react-native'
import MyText from '../../elements/MyText'
import { useSelector } from 'react-redux'
import MyStatusBar from '../../elements/MyStatusBar'
import HeaderTwo from '../../components/Header'
import { useFocusEffect } from '@react-navigation/native'
import { DOMAIN } from '../../services/Config'


const Data = [
    {
        id: 1,
        name: "iPhone 11 pro ",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZ032m4BO7E0ceS_SM0cRiMgn9uAIHzLbBmA&s",
        amt: "29.00"
    },
    {
        id: 2,
        name: "Motorcycle jacket ",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUildVeakfCBxylFDyisGCtQ7fyxw20lHWug&s",
        amt: "60.00"

    },
    {
        id: 3,
        name: "Quad bike ",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPjdPd2FnNTIDDHweeN7kv0tY1v-QlA_y6gw&s",
        amt: "200.00"

    },
    {
        id: 4,
        name: "electric kettle",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvTJkLYR0zoJgI1cKiigWOTI8BUtmZol6ctQ&s",
        amt: "29.00"

    }
]

const ChatScreen = ({ navigation }) => {
    const userDetails = useSelector((state) => state?.user?.user)
    const [show, setShow] = useState("Products")
    const [chatList, setChatList] = useState([])
    const [loading, setLoading] = useState(false)

    useFocusEffect(
        React.useCallback(() => {
            _getChatC()
        }, [])
    )

    const _getChatC = () => {
        setLoading(true)
        const myHeaders = new Headers();
        myHeaders.append("Accept", "application/json");
        myHeaders.append("Authorization", `Bearer ${userDetails?.access_token}`);
        var formdata = new FormData();
        formdata.append("receiver_id", userDetails?.id);
        const requestOptions = {
            method: "POST",
            body: formdata,
            headers: myHeaders,
            redirect: "follow"
        };
        fetch(`${DOMAIN}get-conversation`, requestOptions)
            .then((response) => response.json())
            .then(async (res) => {
                if (res.status == "1") {
                    setChatList(res?.result)
                }
            }).catch((err) => {
                console.log("err", err)
            })
    }

    return (
        <View style={{ flex: 1, backgroundColor: "#fff" }}>
            <MyStatusBar backgroundColor={"transparent"} barStyle={"dark-content"} />
            <HeaderTwo back={true} navigation={navigation} title={"Message"} />
            <ScrollView style={{ backgroundColor: "#fff", flex: 1, padding: 20, paddingTop: 5 }}>
                <View style={{ backgroundColor: "#FBFBFB", flexDirection: "row", alignItems: "center" }}>
                    <Pressable onPress={() => setShow("Products")} style={{ width: "48%", padding: 18, backgroundColor: show == "Products" ? "#04CFA4" : "transparent", justifyContent: "center", alignItems: "center", borderRadius: 10 }}>
                        <MyText h6 semibold style={{ color: show == "Products" ? "#fff" : "#757575" }}>
                            Message
                        </MyText >
                    </Pressable>
                    <Pressable onPress={() => setShow("Searches")} style={{ width: "48%", padding: 18, backgroundColor: show == "Searches" ? "#04CFA4" : "transparent", justifyContent: "center", alignItems: "center", borderRadius: 10 }}>
                        <MyText h6 semibold style={{ color: show == "Searches" ? "#fff" : "#757575" }}>
                            Notification
                        </MyText >
                    </Pressable>

                </View>
                {show == "Products" ?
                    <View style={{ width: "100%", marginTop: 20 }}>
                        <MyText h5 bold style={{ color: "#000" }}>Chat</MyText>
                        {chatList?.length == 0 ? null
                            :
                            chatList.map((item, index) => {
                                return (
                                    <Pressable onPress={() => navigation.navigate("ChattingScreen", {
                                        item: {
                                            image: "",
                                            name: item?.user_name,
                                            product_id: item?.product_id,
                                            reciever_id: item?.sender_id
                                        }
                                    })} key={index} style={{ alignItems: "center", backgroundColor: "#fff", flexDirection: "row", justifyContent: "space-between", borderColor: "#949494", paddingVertical: 20 }}>
                                        <View style={{ width: 60, height: 60, borderRadius: 40 / 2, backgroundColor: "#CACACA40" }}>
                                            <Image source={{ uri: item?.image }} style={{ width: "100%", height: "100%", borderRadius: 40 / 2, }} />
                                        </View>
                                        <View style={{ width: "82%" }}>
                                            <MyText h5 bold>{item.user_name}</MyText>
                                            <MyText h6 regular style={{ color: "#949494" }}>{item?.last_message}</MyText>
                                        </View>
                                        {/* <MyText h6 regular style={{ color: "#949494" }}>2 hours ago</MyText> */}
                                    </Pressable>
                                )
                            })}
                    </View>
                    :
                    <View style={{ width: "100%", flexDirection: "row", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", marginVertical: 20 }}>
                        {[1, 2, 3, 4, 5, 6, 7].map((item, index) => {
                            return (
                                <View key={index} style={{ alignItems: "center", backgroundColor: "#fff", flexDirection: "row", justifyContent: "space-between", borderColor: "#949494", paddingVertical: 20 }}>
                                    <View style={{ width: 60, height: 60, borderRadius: 40 / 2, backgroundColor: "#CACACA40" }}>
                                    </View>
                                    <View style={{ width: "58%" }}>
                                        <MyText h5 bold>Mackbook</MyText>
                                        <MyText h6 regular style={{ color: "#949494" }}>RNemo enim ipsam voluptatem quia voluptas sit aspernatur</MyText>
                                    </View>
                                    <MyText h6 regular style={{ color: "#949494" }}>2 hours ago</MyText>
                                </View>
                            )
                        })}
                    </View>
                }
            </ScrollView>

        </View>
    )
}

export default ChatScreen
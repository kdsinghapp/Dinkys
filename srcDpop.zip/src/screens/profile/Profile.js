
/* eslint-disable semi */
/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from 'react'
import {
    Pressable, View, TextInput, ScrollView, Image
} from 'react-native'
import MyStatusBar from '../../elements/MyStatusBar'
import MyText from '../../elements/MyText'
import { useDispatch, useSelector } from 'react-redux'
import ProRight from "../../assets/svg/proright.svg"
import HeaderTwo from '../../components/Header'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { useFocusEffect } from '@react-navigation/native'
import { DOMAIN } from '../../services/Config'

const Profile = ({ navigation }) => {
    const userDetailData = useSelector((state) => state.user.user)
    const [user, setUser] = useState(null)
    const dispatch = useDispatch()

    useFocusEffect(
        React.useCallback(() => {
            _get_profile()
        }, [userDetailData])
    )

    const _get_profile = () => {
        const myHeaders = new Headers();
        myHeaders.append("Accept", "application/json");
        myHeaders.append("Authorization", `Bearer ${userDetailData?.access_token}`);
        const requestOptions = {
            method: "GET",
            headers: myHeaders,
            redirect: "follow"
        };
        fetch(`${DOMAIN}get-profile`, requestOptions)
            .then((response) => response.json())
            .then(async (res) => {
                if (res.status == "1") {
                    dispatch({ type: "WALLET", payload: res?.data?.wallet });
                    setUser(res?.data)
                }
            }).catch((err) => {
                console.log("err", err)
            })
    }


    return (
        <View style={{ flex: 1, backgroundColor: "#F9F9F9" }}>
            <MyStatusBar backgroundColor={"transparent"} barStyle={"dark-content"} />
            <HeaderTwo navigation={navigation} back={true} title={"Profile"} />
            <ScrollView style={{ flex: 1 }}>
                <View style={{ alignItems: "center", backgroundColor: "#fff", flexDirection: "row", padding: 25, justifyContent: "space-between" }}>
                    <View style={{ width: 80, height: 80, borderRadius: 80 / 2, borderWidth: 0.5, overflow: "hidden" }}>
                        {user?.image?.length === 0 ? null : <Image source={{ uri: user?.image }} style={{ width: "100%", height: "100%", borderRadius: 80 / 2 }} />}
                    </View>
                    <View style={{ width: "67%" }}>
                        <MyText h5 bold>{user?.user_name}</MyText>
                        <MyText h6 regular>{user?.email}</MyText>
                        <MyText h6 regular>4.5</MyText>
                    </View>
                    <ProRight width={16} height={16} />
                </View>
                <View style={{ backgroundColor: "transparent", padding: 25, justifyContent: "space-between", paddingVertical: 20 }}>
                    <MyText h5 bold style={{ color: "#04CFA4" }} >Transection</MyText>
                </View>
                <View style={{ backgroundColor: "#fff", padding: 25, }}>
                    <Pressable
                        onPress={() => navigation.navigate("Purchases")}
                        style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-between" }}>
                        <MyText h5 regular>Purchases</MyText>
                        <ProRight width={24} height={24} />
                    </Pressable>
                    <Pressable
                        onPress={() => navigation.navigate("Sales")}
                        style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-between", marginVertical: 30 }}>
                        <MyText h5 regular>Sales</MyText>
                        <ProRight width={24} height={24} />
                    </Pressable>
                    <Pressable
                        onPress={() => navigation.navigate("Wallet", { user })}
                        style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-between" }}>
                        <MyText h5 regular>Wallet</MyText>
                        <ProRight width={24} height={24} />
                    </Pressable>
                </View>
                <View style={{ backgroundColor: "transparent", padding: 25, justifyContent: "space-between", paddingVertical: 20 }}>
                    <MyText h5 bold style={{ color: "#04CFA4" }} >Account</MyText>
                </View>
                <View style={{ backgroundColor: "#fff", padding: 25, }}>
                    <Pressable onPress={() => user == null ? null : navigation.navigate("SettingScreen", { userDetails: user })} style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-between" }}>
                        <MyText h5 regular>Setting</MyText>
                        <ProRight width={24} height={24} />
                    </Pressable>
                    <Pressable style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-between", marginVertical: 30 }}>
                        <MyText h5 regular>Help</MyText>
                        <ProRight width={24} height={24} />
                    </Pressable>
                    <Pressable onPress={() => {
                        AsyncStorage.clear(),
                            dispatch({ type: 'SET_USER', payload: null }),
                            navigation.navigate("Login")
                    }} style={{ alignItems: "center", flexDirection: "row", justifyContent: "space-between" }}>
                        <MyText h5 regular>Logout</MyText>
                        <ProRight width={24} height={24} />
                    </Pressable>
                </View>
            </ScrollView>

        </View >
    )
}

export default Profile
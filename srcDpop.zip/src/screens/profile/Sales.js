
/* eslint-disable semi */
/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from 'react'
import { Image, Pressable, ScrollView, Alert, View, FlatList, TouchableOpacity, TextInput, BackHandler, ActivityIndicator } from 'react-native'
import MyText from '../../elements/MyText'
import { useSelector } from 'react-redux'
import MyStatusBar from '../../elements/MyStatusBar'
import HeaderTwo from '../../components/Header'
import { useFocusEffect } from '@react-navigation/native'
import { DOMAIN } from '../../services/Config'
import OrderSalesDetails from '../../components/OrderSalesDetails'


const Data = [
    {
        id: 1,
        name: "iPhone 11 pro ",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZ032m4BO7E0ceS_SM0cRiMgn9uAIHzLbBmA&s",
        amt: "29.00"
    },
    {
        id: 2,
        name: "Motorcycle jacket ",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUildVeakfCBxylFDyisGCtQ7fyxw20lHWug&s",
        amt: "60.00"

    },
    {
        id: 3,
        name: "Quad bike ",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPjdPd2FnNTIDDHweeN7kv0tY1v-QlA_y6gw&s",
        amt: "200.00"

    },
    {
        id: 4,
        name: "electric kettle",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvTJkLYR0zoJgI1cKiigWOTI8BUtmZol6ctQ&s",
        amt: "29.00"

    }
]

const Sales = ({ navigation }) => {
    const userDetails = useSelector((state) => state?.user?.user)
    const [show, setShow] = useState("wind")
    const [loading, setLoading] = useState(false)
    const [purchase, setPurchase] = useState([])
    const [open, setOpen] = useState(false)
    const [data, setData] = useState(undefined)

    useFocusEffect(
        React.useCallback(() => {
            _purchase_list()
        }, [show])
    )

    const _inprogressHandler = () => {
        setOpen(false)
        setLoading(true)
        var formdata = new FormData();
        formdata.append("product_id", userDetails?.id);
        formdata.append("status", "inprogress");
        const requestOptions = {
            method: "POST",
            body: formdata,
            redirect: "follow"
        };
        fetch(`${DOMAIN}change_product_status`, requestOptions)
            .then((response) => response.json())
            .then(async (res) => {
                if (res?.status == "1") {
                    _purchase_list()
                }
            }).catch((err) => {
                console.log("err", err)
            }).finally(() => {
                setLoading(false)
            })
    }

    const _purchase_list = () => {
        setLoading(true)
        var formdata = new FormData();
        formdata.append("user_id", userDetails?.id);
        formdata.append("status", show);
        const requestOptions = {
            method: "POST",
            body: formdata,
            redirect: "follow"
        };
        fetch(`${DOMAIN}get-products-by-user-id`, requestOptions)
            .then((response) => response.json())
            .then(async (res) => {
                if (res?.status == "1") {
                    setPurchase(res?.products)
                } else {
                    setPurchase([])
                }
            }).catch((err) => {
                console.log("err", err)
            }).finally(() => {
                setLoading(false)
            })
    }

    return (
        <View style={{ flex: 1, backgroundColor: "#fff" }}>
            <MyStatusBar backgroundColor={"transparent"} barStyle={"dark-content"} />
            <HeaderTwo navigation={navigation} title={"Sales"} />
            <ScrollView contentContainerStyle={{ backgroundColor: "#fff", flex: 1, padding: 20 }}>
                <View style={{ backgroundColor: "#FBFBFB", flexDirection: "row", alignItems: "center" }}>
                    <Pressable onPress={() => setShow("wind")} style={{ width: "33.33%", padding: 18, backgroundColor: show == "wind" ? "#04CFA4" : "transparent", justifyContent: "center", alignItems: "center", borderRadius: 10 }}>
                        <MyText h6 semibold style={{ color: show == "wind" ? "#fff" : "#757575" }}>
                            In wind
                        </MyText >
                    </Pressable>
                    <Pressable onPress={() => setShow("inprogress")} style={{ width: "33.33%", padding: 18, backgroundColor: show == "inprogress" ? "#04CFA4" : "transparent", justifyContent: "center", alignItems: "center", borderRadius: 10 }}>
                        <MyText h6 semibold style={{ color: show == "inprogress" ? "#fff" : "#757575" }}>
                            In progress
                        </MyText >
                    </Pressable>
                    <Pressable onPress={() => setShow("Complete")} style={{ width: "33.33%", padding: 18, backgroundColor: show == "Complete" ? "#04CFA4" : "transparent", justifyContent: "center", alignItems: "center", borderRadius: 10 }}>
                        <MyText h6 semibold style={{ color: show == "Complete" ? "#fff" : "#757575" }}>
                            Finished
                        </MyText >
                    </Pressable>
                </View>
                {loading ?
                    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                        <ActivityIndicator size={"small"} />
                    </View>
                    :
                    purchase?.length == 0 ?
                        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                            <MyText>No data here...</MyText>
                        </View>
                        :
                        <View style={{ flex: 1, width: "100%", flexDirection: "row", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", marginVertical: 20 }}>
                            {purchase.map((item, index) => {
                                return (
                                    <Pressable
                                        onPress={() => { setOpen(true), setData(item) }}
                                        key={index}
                                        style={{
                                            width: "48%",
                                            borderRadius: 12,
                                            shadowOpacity: 0.8,
                                            shadowRadius: 2,
                                            shadowOffset: {
                                                height: 0,
                                                width: 0
                                            },
                                            backgroundColor: "#fff",
                                            elevation: 5,
                                            marginBottom: 15
                                        }}>
                                        <View style={{
                                            borderRadius: 12,
                                            backgroundColor: "#fff",
                                            height: 172,
                                            overflow: "hidden"
                                        }}>
                                            <Image source={{ uri: item?.product_images[0].image }} style={{
                                                width: "100%", height: "100%", borderTopLeftRadius: 12,
                                                borderTopRightRadius: 12,
                                            }} />
                                        </View>
                                        <View style={{ justifyContent: "center", margin: 5, backgroundColor: "#fff", padding: 8 }}>
                                            <MyText h6 bold style={{ color: "#04CFA4" }}>
                                                € {item?.price}
                                            </MyText >
                                            <MyText h6 semibold style={{ color: "#000" }}>
                                                {item?.title}
                                            </MyText >
                                            <MyText h6 regular style={{ color: "#949494" }}>
                                                {item?.description}
                                            </MyText >
                                        </View>
                                    </Pressable>
                                )
                            })}
                        </View>
                }
            </ScrollView>
            <OrderSalesDetails
                isVisible={open}
                onBackdropPress={() => setOpen(false)}
                data={data}
                type={show}
                onDone={_inprogressHandler}
            />
        </View>
    )
}

export default Sales